
var app = angular.module("myShoppingList", ['googlechart']); 
app.controller("myCtrl", function($scope,$http) {
	
	

   $http.get("url")
  .then(function(response) {
      $scope.countryName = response.data;
  });
    var chart1 = {};
	var tempc = $scope.countryName
	var tempN = 450;
	    var temp = [tempc, tempN];
		chart1.type = "GeoChart";
    

chart1.data = [
  ['Country', 'heelo'],
          ['Germany', 200],
          ['United States', 300],
          ['Brazil', 400],
          ['Canada', 500],
          ['France', 600],
          ['RU', 700]
];

chart1.data.push(temp);

chart1.options = {
  width: 600,
  height: 300,
  chartArea: {left:10,top:10,bottom:0,height:"100%"},
  colorAxis: {colors: ['blue', 'red']},
  displayMode: 'regions'
};

chart1.formatters = {
  number : [{
    columnNum: 1,
    pattern: " #,##0.00"
  }]
};

$scope.chart = chart1;

var ctxL = document.getElementById("lineChart").getContext('2d');
var myLineChart = new Chart(ctxL, {
type: 'line',
data: {
labels: ["January", "February", "March", "April", "May", "June", "July"],
datasets: [{
label: "entered data",
data: [65, 59, 80, 81, 56, 55, 40],
backgroundColor: [
'rgba(105, 0, 132, .2)',
],
borderColor: [
'rgba(200, 99, 132, .7)',
],
borderWidth: 2
},
{
label: "crawler progress",
data: [28, 48, 40, 19, 86, 27, 90],
backgroundColor: [
'rgba(0, 137, 132, .2)',
],
borderColor: [
'rgba(0, 10, 130, .7)',
],
borderWidth: 2
}
]
},
options: {
responsive: true
}
});
});
